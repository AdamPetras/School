/*
 * io.h
 *
 *  Created on: 4. 4. 2017
 *    Solution: IJC-DU2, příklad
 *      Author: Adam Petráš, FIT
 *    Compiled: GCC 5.4.0 20160609
 */

#ifndef IO_H_
#define IO_H_
#include <stdio.h>
int get_word(char *s, int max, FILE *f);

#endif /* IO_H_ */
