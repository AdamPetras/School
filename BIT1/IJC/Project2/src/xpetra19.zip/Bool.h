/*
 * Bool.h
 *
 *  Created on: 4. 4. 2017
 *    Solution: IJC-DU2, příklad
 *      Author: Adam Petráš, FIT
 *    Compiled: GCC 5.4.0 20160609
 */
 */

#ifndef BOOL_H_
#define BOOL_H_
#define true 1
#define false 0
#define Bool int


#endif /* BOOL_H_ */
