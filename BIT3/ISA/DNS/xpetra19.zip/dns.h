#ifndef DNS_H
#define DNS_H
//CODE
#endif